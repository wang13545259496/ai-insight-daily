# AI Insight Daily 部署说明

> 版本：V2.0（2026-10-16 核实重写）
> V1.0 写于 2026-10-05，当时站点尚未接入 Cloudflare 隧道，
> 本文档经过两轮修正：①「nginx 作用：域名解析、HTTPS」不实；
> ② nginx 实际不在链路上，已于 2026-10-17 停用。

---

## 一、服务器环境

| 项 | 值 |
| --- | --- |
| 运行环境 | Windows + WSL2 Ubuntu（发行版 Ubuntu 26.04） |
| Linux 用户 | `administrator` |
| 项目路径 | `/home/administrator/projects/ai-insight-daily` |
| 公网域名 | https://aibiliai.com |

### 运行时版本（实测于 2026-10-16）

| 组件 | 版本 |
| --- | --- |
| Node.js | v22.23.3 |
| npm | 10.9.9 |
| Next.js | 16.3.5 |
| React | 19.2.8 |
| Prisma Client | 6.19.3 |
| PM2 | 7.0.4 |
| cloudflared | 2026.10.0 |

---

## 二、网络架构

**这是 V1.0 遗漏的关键部分。**

```
浏览器
  │  HTTPS
  ▼
Cloudflare 边缘  ← 证书由 Cloudflare 提供，自动续期
  │  加密隧道（cloudflared 主动外连，无需公网 IP、不开放入站端口）
  ▼
cloudflared（本机常驻进程）
  │
  ▼
Next.js  0.0.0.0:3000
  │
  ▼
Prisma ORM
  │
  ▼
SQLite  prisma/dev.db
```

### 各层职责（易混淆，务必分清）

| 层 | 职责 | 不负责什么 |
| --- | --- | --- |
| **Cloudflare** | DNS 解析、HTTPS 证书、HTTP→HTTPS 跳转 | 不管应用逻辑 |
| **cloudflared** | 建立隧道，把公网请求转到本机 3000 | 不处理业务 |
| **Next.js** | 应用本身（同时承担 HTTP 服务） | — |

### 隧道回源到 3000，不经过 nginx

隧道 ingress 的实际配置（从 cloudflared 日志读取）：

```json
{"hostname":"aibiliai.com","service":"http://127.0.0.1:3000"}
```

即请求直接交给 Next.js，**本机不设反向代理**。

> **历史说明**：早期曾用 nginx 监听 80 反代到 3000，文档也据此写过
> 「隧道回源到本机 80」。但实际隧道配置指向 3000，nginx 从未处理过
> 真实流量 —— 2026-10-17 实测其访问日志中非 127.0.0.1 的请求为 0 条，
> 已停用。

因此：

- 服务器**不需要**公网 IP，**不需要**开放任何入站端口
- 本机不需要配置 HTTPS 证书（由 Cloudflare 边缘提供）
- 隧道由 cloudflared **主动向 Cloudflare 建立**出站连接

> 验证：`ss -tlnp | grep :3000` 应看到 `0.0.0.0:3000`（Next.js）。
> `0.0.0.0` 表示同时监听局域网，因此手机等设备可通过
> `http://<本机IP>:3000` 访问，无需端口转发。

### 隧道是唯一的对外通路

**cloudflared 停止 = 网站立即下线**（实际发生过一次）。
排查网站打不开时，`systemctl status cloudflared` 是必查项。

---

## 三、Web 服务：Next.js（本机无反向代理）

**nginx 已于 2026-10-17 停用。**

停用理由：隧道 ingress 指向 `http://127.0.0.1:3000`，请求从未经过 nginx。
实测其访问日志中非 `127.0.0.1` 的请求为 0 条 —— 它一直在空转，
却因文档写着「隧道回源到 80」而被误认为在链路上。

原配置保留在 `/etc/nginx/sites-available/ai-insight-daily`，未删除，
需要时可 `sudo systemctl start nginx` 临时启用。

**Next.js 监听**：

```bash
ss -tlnp | grep :3000
# 0.0.0.0:3000  ← 同时监听局域网，手机可直接访问 http://<本机IP>:3000
```

**没有代理层超时**：过去 nginx 的 `proxy_read_timeout 60s` 曾是行程生成
（40-60 秒）的隐患。现在请求直连 Next.js，约束只剩两端：

- Next.js 自身不设请求超时（长任务可跑完）
- Cloudflare 免费版对源站的响应上限约 100 秒

> 若未来出现长任务接近 100 秒，需要考虑改为异步任务 + 轮询，
> 而不是依赖超时配置。

---

### 隧道参数（2026-10-17 实测修正）

隧道必须以 IPv4 + HTTP/2 运行，否则会反复断开。详见
[`AI_TROUBLESHOOTING_GUIDE.md`](./AI_TROUBLESHOOTING_GUIDE.md)。

```ini
# /etc/systemd/system/cloudflared-ipv4.service
ExecStart=/usr/bin/cloudflared --no-autoupdate \
  --edge-ip-version 4 \
  --edge-bind-address 0.0.0.0 \
  --protocol http2 \
  tunnel run --token-file /etc/cloudflared/token
```

管理命令：

```bash
bash scripts/manage-cloudflared.sh status     # 查状态与协议
sudo bash scripts/manage-cloudflared.sh install    # 安装/更新
sudo bash scripts/manage-cloudflared.sh rollback   # 切回原服务
```

---

## 四、应用管理：PM2

| 项 | 值 |
| --- | --- |
| 进程名 | `ai-insight-daily` |
| 启动命令 | `npm start`（即 `next start -H 0.0.0.0`） |
| 运行目录 | `/home/administrator/projects/ai-insight-daily` |

```bash
pm2 list
pm2 logs ai-insight-daily
pm2 logs ai-insight-daily --err --lines 30
pm2 restart ai-insight-daily --update-env
pm2 describe ai-insight-daily
```

### `--update-env` 不能省

修改 `.env.local` 或 `.env.production` 后，**必须**加 `--update-env`，
否则 PM2 会沿用启动时捕获的旧环境变量，改动不生效。

```bash
# ✓ 正确
pm2 restart ai-insight-daily --update-env

# ✗ 改了环境变量却不生效
pm2 restart ai-insight-daily
```

### 判断服务是否稳定

看 `pm2 describe` 的这三个字段：

| 字段 | 含义 |
| --- | --- |
| `restarts` | 累计重启次数。**部署或手动重启也会计入**，数值本身不代表有问题 |
| `unstable restarts` | 异常重启次数。**这个才是崩溃信号**，应保持 0 |
| `uptime` | 本次运行时长。只有几十秒说明刚重启过 |

> 不要把 `restarts` 数值偏高误判为崩溃循环 —— 正常部署也会累加。

---

## 五、构建部署流程

```bash
cd ~/projects/ai-insight-daily

# 1. 安装依赖（用 ci 而非 install，严格按 package-lock.json）
npm ci

# 2. 构建
npm run build

# 3. 重启
pm2 restart ai-insight-daily --update-env
```

### 构建时不要删除 `.next`

```bash
# ✗ 服务运行中删除构建目录 → 全站 502，直到构建完成
rm -rf .next && npm run build

# ✓ 直接构建（Next 会增量更新），成功后再重启
npm run build && pm2 restart ai-insight-daily --update-env
```

### 数据库结构变更

本项目用 **Prisma Migrate** 管理表结构（`prisma/migrations/`，数据库内有
`_prisma_migrations` 表记录已应用项）。

```bash
npx prisma migrate dev --name 描述      # 开发时生成并应用迁移
npx prisma migrate deploy               # 部署时应用待执行迁移
npx prisma migrate status               # 查看状态

# ✗ 危险：db push 在检测到结构漂移时可能删除列
npx prisma db push
```

---

## 六、开机自启

三层都要正常，缺一层则重启电脑后网站起不来。

| 层 | 机制 | 检查命令 |
| --- | --- | --- |
| **WSL** | `/etc/wsl.conf` 设 `systemd=true` | 无需操作 |
| **PM2** | systemd 服务 `pm2-administrator` 执行 `pm2 resurrect` | `systemctl is-enabled pm2-administrator` |
| **cloudflared** | systemd 服务 | `systemctl is-enabled cloudflared` |

**PM2 的自启依赖 `~/.pm2/dump.pm2`**（进程快照）。
新增或重命名进程后必须执行 `pm2 save`，否则重启后不会恢复。

自启配置命令（换机器时用）：

```bash
pm2 startup systemd -u administrator --hp /home/administrator
# 复制该命令输出的 sudo 行并执行
pm2 save
```

---

## 七、定时任务

```bash
crontab -l
```

| 时间 | 任务 |
| --- | --- |
| `0 2 * * *` | 调用 `/api/cron/daily` 抓取资讯（Bearer 鉴权） |
| `0 23 * * *` | 数据库异地备份（调度脚本自行判断是否真的需要跑） |
| `@reboot` | 开机补跑备份 |

### 这台机器不是 24 小时开机

**cron 不会补跑错过的任务。** 凌晨时段机器常处于关机状态。

实际后果：原 `0 3 * * *` 的备份任务在 10 天里只成功执行过 1 次。

**新增定时任务前，先确认目标时间点机器是否在运行。**
需要「必定执行」的任务，应改用「定时触发 + 判断上次执行时间」的模式
（参考 `scripts/db-backup-scheduler.sh`）。

---

## 八、注意事项

**不要随意修改**：隧道服务配置、PM2 配置、生产环境变量。修改前先备份。

**改完必须验证**：本项目发生过多次「代码正确但线上未生效」，原因包括构建失败、
服务未重启、环境变量未更新。验证方式是用 `curl` 实际请求页面或接口，
检查响应内容是否包含新改动 —— 不要只看构建日志。

**安全要点**：

- `.env.local` 含全部密钥，**已被 git 忽略**，不进仓库
- 旅行模块口令存于 `TRAVEL_PASSWORD`，未设置时该模块完全公开
- 站点已启用 Always Use HTTPS，`COOKIE_SECURE` 应为 `1`

---

## 九、相关文档

| 文档 | 内容 |
| --- | --- |
| `RECOVERY.md`（项目根目录） | 电脑损坏后在新机器上重建站点的完整步骤 |
| `AI-START-HERE.md`（项目根目录） | 改动流程、验证要求、当前已知问题 |
| `ai-context/AI_TROUBLESHOOTING_GUIDE.md` | 故障排查手册（含实测案例） |
| `ai-context/ARCHITECTURE.md` | 技术架构与数据流 |
