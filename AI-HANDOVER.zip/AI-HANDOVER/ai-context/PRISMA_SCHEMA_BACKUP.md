generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = "file:./dev.db"
}

model Source {
  id                Int       @id @default(autoincrement())
  name              String    @unique
  url               String
  rssUrl            String?
  type              String    @default("rss")
  status            String    @default("active")
  enabled           Boolean   @default(true)
  errorCount        Int       @default(0)
  lastFetch         DateTime?
  rssStatus         String    @default("unknown")
  rssScore          Int       @default(0)
  rssFailCount      Int       @default(0)
  rssEnabled        Boolean   @default(true)
  rssWeight         Int       @default(100)
  rssSuccessCount   Int       @default(0)
  rssTotalCount     Int       @default(0)
  rssPausedAt       DateTime?
  lastCheckTime     DateTime?
  lastResponseTime  Int?
  lastError         String?
  lastCollectTime   DateTime?
  nextCollectTime   DateTime?
  collectCount      Int       @default(0)
  collectErrorCount Int       @default(0)
  lastCollectError  String?
  createdAt         DateTime  @default(now())
  updatedAt         DateTime  @default(now()) @updatedAt
  news              News[]
  RSSLog            RSSLog[]
}

model News {
  id Int @id @default(autoincrement())

  // ==============================
  // 基础新闻信息
  // ==============================

  title String

  category String

  // 新闻背景

  background String?

  // AI摘要

  summary String

  // 新闻正文

  content String

  // 新闻来源

  source String

  sourceUrl String?

  publishedAt DateTime?

  // 是否验证

  verified Boolean @default(false)

  // ==============================
  // 新闻质量状态
  // V7.4.8.10.5.5.8.6.7.1
  // ==============================

  // active
  // repair
  // archived

  dataStatus String @default("active")

  // 数据清洗原因

  cleanReason String?

  // ==============================
  // 多源融合
  // ==============================

  sourceCount Int @default(1)

  duplicateHash String? @unique

  mergedSources String?

  originalSourceCount Int @default(1)

  // ==============================
  // AI新闻价值增强系统
  // V7.4.8.10.5.5.9.2
  // ==============================

  // AI一句话洞察

  insight String?

  // 行业影响分析

  impact String?

  // 商业机会分析

  businessOpportunity String?

  // 投资观察

  investmentView String?

  // AI价值评分

  aiScore Float @default(0)

  // AI分析状态

  // pending
  // completed

  analysisStatus String @default("pending")

  // ==============================
  // 事件关联
  // ==============================

  sourceId Int?

  eventId Int?

  createdAt DateTime @default(now())

  // ==============================
  // Prisma关系
  // 注意保持单行格式
  // ==============================

  sourceRef Source? @relation(fields: [sourceId], references: [id])

  event NewsEvent? @relation(fields: [eventId], references: [id])

  investmentSources Investment[] @relation("InvestmentSourceNews")
}

model DailyReport {
  id        Int      @id @default(autoincrement())
  title     String
  content   String
  date      String   @unique
  createdAt DateTime @default(now())
}

model BusinessOpportunity {
  id             Int              @id @default(autoincrement())
  industry       String
  opportunity    String
  trend          String
  direction      String
  description    String
  createdAt      DateTime         @default(now())
  BusinessReport BusinessReport[]
}

model BusinessReport {
  id                  Int                 @id @default(autoincrement())
  businessId          Int
  marketAnalysis      String
  painPoints          String
  aiSolution          String
  productDesign       String
  businessModel       String
  riskAnalysis        String
  startupAdvice       String
  createdAt           DateTime            @default(now())
  BusinessOpportunity BusinessOpportunity @relation(fields: [businessId], references: [id])
}

model Investment {
  id          Int    @id @default(autoincrement())
  name        String
  industry    String
  description String

  businessScore   Int
  technologyScore Int
  marketScore     Int
  growthScore     Int
  riskScore       Int

  // ==============================
  // 投资来源证据链
  // ==============================

  sourceNewsId  Int?
  sourceEventId Int?

  // company / startup / platform /
  // infrastructure / theme
  sourceType String?

  // 说明为什么进入投资候选
  sourceReason String?

  createdAt DateTime @default(now())

  sourceNews  News?      @relation("InvestmentSourceNews", fields: [sourceNewsId], references: [id], onDelete: SetNull)
  sourceEvent NewsEvent? @relation("InvestmentSourceEvent", fields: [sourceEventId], references: [id], onDelete: SetNull)

  InvestmentFavorite InvestmentFavorite[]
  InvestmentScore    InvestmentScore[]

  @@index([sourceNewsId])
  @@index([sourceEventId])
}

model InvestmentFavorite {
  id           Int        @id @default(autoincrement())
  investmentId Int
  createdAt    DateTime   @default(now())
  Investment   Investment @relation(fields: [investmentId], references: [id], onDelete: Cascade)
}

model InvestmentScore {
  id           Int        @id @default(autoincrement())
  investmentId Int
  total        Int
  level        String
  createdAt    DateTime   @default(now())
  Investment   Investment @relation(fields: [investmentId], references: [id], onDelete: Cascade)
}

model RSSLog {
  id           Int      @id @default(autoincrement())
  sourceId     Int
  status       String
  newsCount    Int      @default(0)
  duration     Int?
  errorMessage String?
  createdAt    DateTime @default(now())
  Source       Source   @relation(fields: [sourceId], references: [id], onDelete: Cascade)
}

model NewsEvent {
  id Int @id @default(autoincrement())

  title String

  keywords String

  summary String

  category String

  // 当前热度
  heatScore Float @default(0)

  // 峰值热度
  peakScore Float @default(0)

  // 趋势状态
  trendStatus String @default("rising")

  // AI分析
  trendSummary String?

  // 状态
  status String @default("active")

  // ======================
  // V7.4.8.10.5.5.8.6.7.3.7.1
  // 事件质量分类
  // ======================

  eventType String @default("unknown")

  qualityScore Float @default(0)

  createdAt DateTime @default(now())

  updatedAt DateTime @default(now())

  news News[]

  investmentSources Investment[] @relation("InvestmentSourceEvent")
}

model IndustryHotspot {
  id Int @id @default(autoincrement())

  name String @unique

  category String

  keywords String

  score Int @default(0)

  trend String @default("stable")

  newsCount Int @default(0)

  recentNewsCount Int @default(0)

  eventCount Int @default(0)

  companyScore Int @default(0)

  description String?

  trends IndustryTrend[]

  createdAt DateTime @default(now())

  updatedAt DateTime @updatedAt
}

model IndustryTrend {
  id Int @id @default(autoincrement())

  hotspotId Int

  date DateTime @default(now())

  score Int

  hotspot IndustryHotspot @relation(fields: [hotspotId], references: [id], onDelete: Cascade)
}

model PageView {
  id        Int      @id @default(autoincrement())
  path      String
  referrer  String?
  device    String?
  createdAt DateTime @default(now())

  @@index([path])
  @@index([createdAt])
}
