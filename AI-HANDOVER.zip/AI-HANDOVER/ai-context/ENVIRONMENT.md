# AI Insight Daily 运行环境信息

更新时间：

Sun Oct 11 10:37:29 CST 2026


## Git信息


当前分支：

main


当前提交：

c67b974 add AI context loading order


最近提交：

c67b974 add AI context loading order
3db0f91 add AI knowledge update policy
cf5a874 add AI backup recovery rules
773d8e2 add AI cost management rules
856f5d6 add AI monitoring standard



## Node环境


Node：

v22.23.3


npm：

10.9.9



## 核心依赖


    "@prisma/client": "^6.19.3",
    "next": "16.3.5",
    "prisma": "^6.19.3",
    "react": "19.2.8",



## Prisma


Prisma schema loaded from prisma/schema.prisma
prisma                  : 6.19.3
@prisma/client          : 6.19.3
Computed binaryTarget   : debian-openssl-3.0.x
Operating System        : linux
Architecture            : x64
Node.js                 : v22.23.3
TypeScript              : 5.9.3
Query Engine (Node-API) : libquery-engine c2990dca591cba766e3b7ef5d9e8a84796e47ab7 (at node_modules/@prisma/engines/libquery_engine-debian-openssl-3.0.x.so.node)
PSL                     : @prisma/prisma-schema-wasm 7.1.1-3.c2990dca591cba766e3b7ef5d9e8a84796e47ab7



## 系统


Linux WCJ 6.18.40.1-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Fri Jul 31 22:12:15 UTC 2026 x86_64 GNU/Linux



## 项目路径


/home/administrator/projects/ai-insight-daily

