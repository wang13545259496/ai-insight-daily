# AI Insight Daily 运行环境信息

更新时间：

Sun Oct 11 10:32:30 CST 2026


## Git信息


当前分支：

main


当前提交：

c19de8b add AI testing standard


最近提交：

c19de8b add AI testing standard
55ff24d add AI decision log
45265dc add AI architecture roadmap
4256222 add AI project onboarding guide
d0f25d9 add AI automation workflow design



## Node环境


Node：

v22.23.3


npm：

10.9.9



## 核心依赖


    "@prisma/client": "^6.19.3",
    "next": "16.3.5",
    "prisma": "^6.19.3",
    "react": "19.2.8",



## Prisma


Prisma schema loaded from prisma/schema.prisma
prisma                  : 6.19.3
@prisma/client          : 6.19.3
Computed binaryTarget   : debian-openssl-3.0.x
Operating System        : linux
Architecture            : x64
Node.js                 : v22.23.3
TypeScript              : 5.9.3
Query Engine (Node-API) : libquery-engine c2990dca591cba766e3b7ef5d9e8a84796e47ab7 (at node_modules/@prisma/engines/libquery_engine-debian-openssl-3.0.x.so.node)
PSL                     : @prisma/prisma-schema-wasm 7.1.1-3.c2990dca591cba766e3b7ef5d9e8a84796e47ab7



## 系统


Linux WCJ 6.18.40.1-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Fri Jul 31 22:12:15 UTC 2026 x86_64 GNU/Linux



## 项目路径


/home/administrator/projects/ai-insight-daily

